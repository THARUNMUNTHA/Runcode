from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Map the home view function to the root URL
    path('signup/', views.signup, name='signup'),  # Map the signup view function to /signup/
    path('profile/', views.profile, name='profile'),  # Map the profile view function to /profile/
    path('post/create/', views.post_create, name='post_create'),  # Map the post_create view function to /post/create/
    path('post/<int:pk>/', views.post_detail, name='post_detail'),  # Map the post_detail view function to /post/<post_id>/
    path('post/<int:pk>/comment/', views.comment_create, name='comment_create'),  # Map the comment_create view function to /post/<post_id>/comment/
]
