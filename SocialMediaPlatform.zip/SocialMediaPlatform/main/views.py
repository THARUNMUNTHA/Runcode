from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
def home(request):
    return render(request, 'home.html')
def profile(request):
    # Your logic for handling the profile view goes here
    return render(request, 'profile.html')

def signup(request):
    # Handle signup logic here if needed
    return render(request, 'signup.html')

def profile_edit(request):
    # Handle profile edit logic here if needed
    return render(request, 'profile_edit.html')

def post_create(request):
    # Handle post creation logic here if needed
    return render(request, 'post_create.html')

def post_detail(request, post_id):
    # Retrieve post from database using post_id
    # post = Post.objects.get(pk=post_id)
    # Pass post object to template
    post = {"author": {"username": "example_user"}, "content": "This is a post content", "created_at": "2022-02-13"}
    return render(request, 'post_detail.html', {'post': post})

def comment_create(request, post_id):
    # Handle comment creation logic here if needed
    return render(request, 'comment_create.html')


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})


# Create your views here.
